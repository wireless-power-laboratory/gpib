# PrologixGPIB
Library for using the Prologix GPIB Ethernet adapter in C#
