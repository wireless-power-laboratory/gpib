GPIB
====

Prologix GPIB C# library

In order to control the Prologix USB box from an C# program. 
Class have not been fully tested yet.
Several issues with non SCPI instruments. Some end up pouring out data without any way to stop it. 
